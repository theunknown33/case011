// المحقق المساعد «الظل» عبر Google Gemini — المفتاح يبقى في متغيرات البيئة ولا يظهر للاعبين.
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const hits = new Map(); // حد بسيط لكل عنوان IP (يعمل بشكل تقريبي على Serverless)

const SYSTEM = `أنت «الظل»، المحقق المساعد في لعبة تحقيق جنائي. أجب عن سؤال اللاعب بتلميحات عملية قصيرة (جملتان إلى ثلاث).
قواعد صارمة:
- لا تذكر اسم القاتل أبداً، ولا الدافع ولا الطريقة، ولا الإجابة الدقيقة لأي سؤال في القضية.
- أرشد اللاعب إلى وثائق وأشخاص وأوقات محددة يجب أن يقارن بينها، وإلى التناقضات المحتملة.
- اعتمد فقط على المعلومات المعطاة لك. لا تخترع وثائق أو أحداثاً جديدة. إن لم تتوفر المعلومة فقل إنها قد تكون في دليل لم يظهر بعد.
- أجب بلغة اللاعب (العربية أو الإنجليزية) وبأسلوب غامض مختصر يليق بمحقق في الظل.`;

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "method" });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(501).json({ error: "not_configured" });
  const ip = String(req.headers["x-forwarded-for"] || "x").split(",")[0].trim();
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  if (list.length >= 25) return res.status(429).json({ error: "rate" });
  list.push(now);
  hits.set(ip, list);
  try {
    const b = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
    const q = String(b.q || "").slice(0, 300);
    if (!q) return res.status(400).json({ error: "q" });
    const people = (Array.isArray(b.people) ? b.people : []).slice(0, 12).map((p) => `- ${String(p.n).slice(0, 60)} (${String(p.r).slice(0, 60)}): ${String(p.t).slice(0, 400)}`).join("\n");
    const docs = (Array.isArray(b.docs) ? b.docs : []).slice(0, 40).map((d) => `- ${String(d.n).slice(0, 80)}: ${String(d.t).slice(0, 500)}`).join("\n");
    const hist = (Array.isArray(b.hist) ? b.hist : []).slice(-6).map((m) => `${m.u === "p" ? "اللاعب" : "الظل"}: ${String(m.t).slice(0, 300)}`).join("\n");
    const user = `القضية: ${String(b.c || "").slice(0, 80)}\n${String(b.intro || "").slice(0, 600)}\nأسئلة محلولة: ${Number(b.solved) || 0}\n\nالأشخاص:\n${people}\n\nالوثائق الظاهرة للاعب الآن:\n${docs}\n\nالمحادثة السابقة:\n${hist}\n\nلغة الرد: ${b.lang === "en" ? "English" : "العربية"}\nسؤال اللاعب: ${q}`;
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents: [{ role: "user", parts: [{ text: user }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: 400 },
      }),
    });
    if (!r.ok) return res.status(502).json({ error: "upstream" });
    const j = await r.json();
    const text = (((j.candidates || [])[0] || {}).content || {}).parts;
    const out = Array.isArray(text) ? text.map((p) => p.text || "").join("").trim() : "";
    if (!out) return res.status(502).json({ error: "empty" });
    return res.status(200).json({ text: out });
  } catch (e) {
    return res.status(500).json({ error: "server" });
  }
};
