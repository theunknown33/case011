// الغرف للعب عن بُعد — تخزين الحالة في Upstash Redis (Vercel Marketplace) عبر REST.
const URL_ = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const TOKEN = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
const TTL = 60 * 60 * 24; // الغرفة تُحذف تلقائياً بعد 24 ساعة
const CODE = /^[A-Z0-9]{4,6}$/;

async function redis(cmd) {
  const r = await fetch(URL_, {
    method: "POST",
    headers: { Authorization: "Bearer " + TOKEN, "Content-Type": "application/json" },
    body: JSON.stringify(cmd),
  });
  const j = await r.json();
  if (j.error) throw new Error(j.error);
  return j.result;
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (!URL_ || !TOKEN) return res.status(501).json({ ok: false, error: "not_configured" });
  try {
    if (req.method === "GET") {
      const code = String((req.query && req.query.code) || "").toUpperCase();
      if (!CODE.test(code)) return res.status(400).json({ ok: false });
      const raw = await redis(["GET", "room:" + code]);
      if (!raw) return res.status(404).json({ ok: false });
      const d = JSON.parse(raw);
      const v = Number((req.query && req.query.v) ?? -1);
      return res.status(200).json({ ok: true, v: d.v, from: d.from, state: v < 0 || d.v > v ? d.state : null });
    }
    if (req.method === "POST") {
      const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
      if (body.a === "create") {
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        for (let i = 0; i < 6; i++) {
          let code = "";
          for (let k = 0; k < 4; k++) code += chars[Math.floor(Math.random() * chars.length)];
          const ok = await redis(["SET", "room:" + code, JSON.stringify({ v: 1, from: "", state: null }), "NX", "EX", TTL]);
          if (ok === "OK") return res.status(200).json({ ok: true, code });
        }
        return res.status(503).json({ ok: false });
      }
      if (body.a === "set") {
        const code = String(body.code || "").toUpperCase();
        if (!CODE.test(code) || !body.state || typeof body.state !== "object") return res.status(400).json({ ok: false });
        const payload = JSON.stringify(body.state);
        if (payload.length > 200000) return res.status(413).json({ ok: false });
        const raw = await redis(["GET", "room:" + code]);
        if (!raw) return res.status(404).json({ ok: false });
        const cur = JSON.parse(raw);
        const next = { v: cur.v + 1, from: String(body.cl || "").slice(0, 16), state: body.state };
        await redis(["SET", "room:" + code, JSON.stringify(next), "EX", TTL]);
        return res.status(200).json({ ok: true, v: next.v });
      }
    }
    return res.status(405).json({ ok: false });
  } catch (e) {
    return res.status(500).json({ ok: false });
  }
};
