# THE UNKNOWN — النشر عبر GitHub + Vercel

## المحتويات
- `public/index.html`: اللعبة كاملة.
- `api/shadow.js`: المحقق المساعد «الظل» عبر Google Gemini (المفتاح سرّي في الخادم).
- `api/room.js`: اللعب عن بُعد بين أجهزة (رمز غرفة) — يحفظ الحالة في Upstash Redis.
- `vercel.json`: رؤوس الأمان. `.env.example`: أسماء المتغيرات المطلوبة.

## 1) رفع المشروع إلى GitHub
1. أنشئ حساباً على github.com ثم New repository (باسم مثل `the-unknown`).
2. من صفحة المستودع: Add file ← Upload files، واسحب **محتويات** هذا المجلد (api, public, package.json, vercel.json, .gitignore) ثم Commit.

## 2) النشر على Vercel
1. vercel.com ← Sign up with GitHub ← Add New ← Project ← اختر المستودع ← Deploy.
2. ستحصل على رابط عام `https://اسم-مشروعك.vercel.app`.

## 3) تفعيل «الظل» بـ Gemini
1. من https://aistudio.google.com/apikey أنشئ مفتاحاً.
2. في Vercel: Project ← Settings ← Environment Variables أضف `GEMINI_API_KEY` (والاختياري `GEMINI_MODEL`، الافتراضي `gemini-2.5-flash`؛ إن أوقفت Google هذا النموذج فاكتب اسم النموذج الجديد من AI Studio).
3. Deployments ← Redeploy. إن لم يُضبط المفتاح أو فشل الاتصال، يجيب الظل بمحرك التلميحات المدمج تلقائياً.

## 4) تفعيل اللعب عن بُعد
1. في Vercel: Project ← Storage ← Create / Marketplace ← **Upstash for Redis** ← اربطه بالمشروع (تُضاف المتغيرات `UPSTASH_REDIS_REST_URL` و`UPSTASH_REDIS_REST_TOKEN` تلقائياً).
2. Redeploy. في اللعبة: «تشكيل الفرق» ← «عن بُعد» ← الجهاز الأول «إنشاء غرفة» فيظهر رمز، والجهاز الثاني يكتبه ويضغط «انضم»، ثم الأول يضغط «افتح ملف القضية».
- كل جهاز يجيب فقط في دور فريقه. الغرفة تُحذف تلقائياً بعد 24 ساعة.
- الجهاز يسأل الخادم كل ثانيتين، فراقب حدود خطة Upstash المجانية إن كثر اللاعبون.

## 5) التحديث بنفس الرابط
عدّل الملفات في GitHub (أو ارفع نسخة جديدة)، وVercel ينشر تلقائياً على الرابط نفسه. النطاق الخاص: Project ← Settings ← Domains.

## ملاحظات مهمة
- خطة Vercel المجانية (Hobby) مخصصة للاستخدام الشخصي غير التجاري حسب شروطها؛ لبيع اللعبة في متجر راجع شروط Vercel أو استعمل خطة مدفوعة.
- التقدم يُحفظ في متصفح كل لاعب (لا قاعدة بيانات للاعبين ولا لوحة إدارة).
- أي شخص يستطيع استدعاء `/api/shadow`؛ فيه حد تقريبي 25 سؤالاً لكل عنوان كل 10 دقائق، وراقب استهلاك مفتاح Gemini من لوحة Google.
